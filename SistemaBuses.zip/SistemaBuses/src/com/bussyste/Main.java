package com.bussyste;

import com.bussystem.dao.*;
import com.bussystem.patterns.behavioral.observer.BusStatusLogger;
import com.bussystem.patterns.structural.BusServiceProxy;
import com.bussystem.patterns.structural.BusSystemFacade;
import com.bussystem.service.*;
import com.bussystem.ui.BusSystemUI;
import com.bussystem.util.DatabaseConnection;
import com.bussystem.model.Bus; // Importar Bus para poder añadir el observador

import java.util.List;

/**
 * Main (Clase Principal):
 * Responsable de inicializar la aplicación y sus componentes.
 * Principio S (Single Responsibility): Su única responsabilidad es el punto de entrada y la orquestación inicial.
 * Principio D (Dependency Inversion): Las dependencias se inyectan aquí.
 */
public class Main {
    public static void main(String[] args) {
        // Inicializar la conexión a la base de datos (Singleton)
        DatabaseConnection.getInstance();

        // Inicializar DAOs
        IBusDAO busDAO = new BusDAOImpl();
        IRouteDAO routeDAO = new RouteDAOImpl();
        IPassengerDAO passengerDAO = new PassengerDAOImpl();
        ITicketDAO ticketDAO = new TicketDAOImpl();
        IBookingDAO bookingDAO = new BookingDAOImpl();

        // Inicializar Servicios (Inyección de Dependencias)
        IBusService busService = new BusService(busDAO);
        IRouteService routeService = new RouteService(routeDAO);
        IPassengerService passengerService = new PassengerService(passengerDAO);
        ITicketService ticketService = new TicketService(ticketDAO);
        IBookingService bookingService = new BookingService(bookingDAO);

        // Aplicar Patrón Proxy al BusService para logging
        IBusService proxiedBusService = new BusServiceProxy(busService);

        // Configurar Observer: Añadir un logger como observador a todos los buses existentes
        BusStatusLogger logger = new BusStatusLogger();
        List<Bus> allBuses = proxiedBusService.getAllBuses(); // Usar el servicio proxied
        for (Bus bus : allBuses) {
            bus.addObserver(logger);
        }
        // Nota: Para nuevos buses, el observador debería ser añadido después de su creación.
        // En un sistema real, esto se manejaría en el servicio o en la fábrica de buses.

        // Inicializar Facade (Patrón Facade)
        BusSystemFacade facade = new BusSystemFacade(proxiedBusService, routeService, passengerService, ticketService, bookingService);

        // Iniciar la Interfaz de Usuario
        BusSystemUI ui = new BusSystemUI(facade);
        ui.start();
    }
}
