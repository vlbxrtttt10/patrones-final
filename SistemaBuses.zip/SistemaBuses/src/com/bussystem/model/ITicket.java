package com.bussystem.model;

/**
 * ITicket (Principio Liskov Substitution y Open/Closed):
 * Principio L (Liskov Substitution): Cualquier subclase de ITicket (StandardTicket, VIPTicket, o cualquier Decorator)
 * debe poder ser sustituida por ITicket sin alterar la corrección del programa.
 * Principio O (Open/Closed): Abierto a extensión (nuevos tipos de boletos o decoradores), cerrado a modificación (no se cambia esta interfaz).
 * Principio I (Interface Segregation): Define solo los métodos necesarios para un boleto básico.
 */
public interface ITicket {
    int getId();
    void setId(int id);
    int getRouteId();
    void setRouteId(int routeId);
    int getBusId();
    void setBusId(int busId);
    int getPassengerId();
    void setPassengerId(int passengerId);
    String getSeatNumber();
    void setSeatNumber(String seatNumber);
    double getBasePrice();
    void setBasePrice(double basePrice);
    double getFinalPrice(); // Este método puede ser modificado por los Decorators
    void setFinalPrice(double finalPrice);
    String getTicketType();
    void setTicketType(String ticketType);
    boolean hasLuggage();
    void setHasLuggage(boolean hasLuggage);
    boolean hasWifi();
    void setHasWifi(boolean hasWifi);
    String getBookingDate();
    void setBookingDate(String bookingDate);

    String getDescription(); // Método para obtener una descripción del boleto, incluyendo decoraciones
}
