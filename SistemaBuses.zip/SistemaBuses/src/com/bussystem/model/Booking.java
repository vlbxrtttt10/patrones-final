package com.bussystem.model;

import com.bussystem.patterns.behavioral.memento.BookingMemento;

/**
 * Booking (POJO y Originator para Memento):
 * Principio S (Single Responsibility): Representa los datos de una reserva.
 * Actúa como el "Originator" en el patrón Memento, creando y restaurando su propio estado.
 */
public class Booking {
    private int id;
    private int ticketId;
    private String status; // Confirmed, Cancelled, Pending

    public Booking(int id, int ticketId, String status) {
        this.id = id;
        this.ticketId = ticketId;
        this.status = status;
    }

    // Constructor para nuevas reservas (sin ID inicial)
    public Booking(int ticketId, String status) {
        this.ticketId = ticketId;
        this.status = status;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getTicketId() { return ticketId; }
    public void setTicketId(int ticketId) { this.ticketId = ticketId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    /**
     * Crea un Memento que contiene el estado actual de la reserva.
     * @return BookingMemento con el estado actual.
     */
    public BookingMemento createMemento() {
        return new BookingMemento(id, ticketId, status);
    }

    /**
     * Restaura el estado de la reserva a partir de un Memento.
     * @param memento El Memento a restaurar.
     */
    public void restoreFromMemento(BookingMemento memento) {
        this.id = memento.getId();
        this.ticketId = memento.getTicketId();
        this.status = memento.getStatus();
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Ticket ID: " + ticketId + ", Estado: " + status;
    }
}
