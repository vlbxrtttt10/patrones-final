package com.bussystem.model;

/**
 * VIPTicket (Principio Liskov Substitution):
 * Implementa ITicket y puede ser sustituido por ITicket.
 * Principio S (Single Responsibility): Representa un boleto VIP.
 */
public class VIPTicket implements ITicket {
    private int id;
    private int routeId;
    private int busId;
    private int passengerId;
    private String seatNumber;
    private double basePrice;
    private double finalPrice;
    private String ticketType = "VIP";
    private boolean hasLuggage = false;
    private boolean hasWifi = true; // VIP tickets include WiFi by default
    private String bookingDate;

    public VIPTicket(int id, int routeId, int busId, int passengerId, String seatNumber, double basePrice, double finalPrice, String bookingDate) {
        this.id = id;
        this.routeId = routeId;
        this.busId = busId;
        this.passengerId = passengerId;
        this.seatNumber = seatNumber;
        this.basePrice = basePrice;
        this.finalPrice = finalPrice;
        this.bookingDate = bookingDate;
    }

    // Constructor para nuevos boletos (sin ID inicial)
    public VIPTicket(int routeId, int busId, int passengerId, String seatNumber, double basePrice, String bookingDate) {
        this.routeId = routeId;
        this.busId = busId;
        this.passengerId = passengerId;
        this.seatNumber = seatNumber;
        this.basePrice = basePrice;
        this.finalPrice = basePrice * 1.2; // VIP tickets are 20% more expensive
        this.bookingDate = bookingDate;
    }

    // Getters y Setters (implementando ITicket)
    @Override public int getId() { return id; }
    @Override public void setId(int id) { this.id = id; }
    @Override public int getRouteId() { return routeId; }
    @Override public void setRouteId(int routeId) { this.routeId = routeId; }
    @Override public int getBusId() { return busId; }
    @Override public void setBusId(int busId) { this.busId = busId; }
    @Override public int getPassengerId() { return passengerId; }
    @Override public void setPassengerId(int passengerId) { this.passengerId = passengerId; }
    @Override public String getSeatNumber() { return seatNumber; }
    @Override public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }
    @Override public double getBasePrice() { return basePrice; }
    @Override public void setBasePrice(double basePrice) { this.basePrice = basePrice; }
    @Override public double getFinalPrice() { return finalPrice; }
    @Override public void setFinalPrice(double finalPrice) { this.finalPrice = finalPrice; }
    @Override public String getTicketType() { return ticketType; }
    @Override public void setTicketType(String ticketType) { this.ticketType = ticketType; }
    @Override public boolean hasLuggage() { return hasLuggage; }
    @Override public void setHasLuggage(boolean hasLuggage) { this.hasLuggage = hasLuggage; }
    @Override public boolean hasWifi() { return hasWifi; }
    @Override public void setHasWifi(boolean hasWifi) { this.hasWifi = hasWifi; }
    @Override public String getBookingDate() { return bookingDate; }
    @Override public void setBookingDate(String bookingDate) { this.bookingDate = bookingDate; }

    @Override
    public String getDescription() {
        return "Boleto VIP (incluye WiFi)";
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Tipo: " + ticketType + ", Asiento: " + seatNumber + ", Precio Final: US$" + String.format("%.2f", finalPrice);
    }
}
