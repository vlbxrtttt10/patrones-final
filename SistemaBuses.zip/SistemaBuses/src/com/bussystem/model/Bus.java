package com.bussystem.model;

import com.bussystem.patterns.behavioral.state.BusState;
import com.bussystem.patterns.behavioral.state.AvailableState;
import com.bussystem.patterns.behavioral.observer.BusSubject;

/**
 * Bus (POJO y Sujeto para Observer, Contexto para State):
 * Principio S (Single Responsibility): Representa los datos de un bus.
 * También actúa como el "Contexto" para el patrón State y el "Sujeto" para el patrón Observer.
 */
public class Bus extends BusSubject {
    private int id;
    private String plateNumber;
    private int capacity;
    private String model;
    private BusState currentState; // Patrón State

    public Bus(int id, String plateNumber, int capacity, String model, String status) {
        this.id = id;
        this.plateNumber = plateNumber;
        this.capacity = capacity;
        this.model = model;
        // Inicializar el estado basado en el string de la DB
        setState(status);
    }

    // Constructor para nuevos buses (sin ID inicial)
    public Bus(String plateNumber, int capacity, String model) {
        this.plateNumber = plateNumber;
        this.capacity = capacity;
        this.model = model;
        this.currentState = new AvailableState(); // Estado inicial por defecto
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getPlateNumber() { return plateNumber; }
    public void setPlateNumber(String plateNumber) { this.plateNumber = plateNumber; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    // Métodos para el patrón State
    public String getStatus() {
        return currentState.getStatusName();
    }

    public void setState(BusState state) {
        this.currentState = state;
        notifyObservers("Estado del bus " + plateNumber + " cambiado a: " + state.getStatusName());
    }

    // Método para inicializar el estado desde un String (ej. de la DB)
    public void setState(String statusName) {
        switch (statusName) {
            case "Available":
                this.currentState = new AvailableState();
                break;
            case "EnRoute":
                this.currentState = new com.bussystem.patterns.behavioral.state.EnRouteState();
                break;
            case "Maintenance":
                this.currentState = new com.bussystem.patterns.behavioral.state.MaintenanceState();
                break;
            default:
                this.currentState = new AvailableState(); // Estado por defecto
                break;
        }
        notifyObservers("Estado del bus " + plateNumber + " inicializado a: " + statusName);
    }

    public void performAction() {
        currentState.handleRequest(this);
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Placa: " + plateNumber + ", Modelo: " + model + ", Capacidad: " + capacity + ", Estado: " + getStatus();
    }
}
