package com.bussystem.model;

/**
 * Route (POJO):
 * Principio S (Single Responsibility): Representa los datos de una ruta.
 */
public class Route {
    private int id;
    private String origin;
    private String destination;
    private double distanceKm;
    private double priceUsd;

    public Route(int id, String origin, String destination, double distanceKm, double priceUsd) {
        this.id = id;
        this.origin = origin;
        this.destination = destination;
        this.distanceKm = distanceKm;
        this.priceUsd = priceUsd;
    }

    // Constructor para nuevas rutas (sin ID inicial)
    public Route(String origin, String destination, double distanceKm, double priceUsd) {
        this.origin = origin;
        this.destination = destination;
        this.distanceKm = distanceKm;
        this.priceUsd = priceUsd;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getOrigin() { return origin; }
    public void setOrigin(String origin) { this.origin = origin; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public double getDistanceKm() { return distanceKm; }
    public void setDistanceKm(double distanceKm) { this.distanceKm = distanceKm; }
    public double getPriceUsd() { return priceUsd; }
    public void setPriceUsd(double priceUsd) { this.priceUsd = priceUsd; }

    @Override
    public String toString() {
        return "ID: " + id + ", Origen: " + origin + ", Destino: " + destination + ", Precio: US$" + String.format("%.2f", priceUsd);
    }
}
