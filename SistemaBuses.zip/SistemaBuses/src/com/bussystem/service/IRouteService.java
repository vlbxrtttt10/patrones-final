package com.bussystem.service;

import com.bussystem.model.Route;
import java.util.List;

public interface IRouteService {
    void addRoute(Route route);
    Route getRouteById(int id);
    List<Route> getAllRoutes();
    void updateRoute(Route route);
    void deleteRoute(int id);
}
