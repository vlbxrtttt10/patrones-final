package com.bussystem.service;

import com.bussystem.dao.IBookingDAO;
import com.bussystem.model.Booking;
import com.bussystem.patterns.behavioral.memento.BookingMemento;
import java.util.List;
import javax.swing.JOptionPane;

public class BookingService implements IBookingService {
    private IBookingDAO bookingDAO;

    public BookingService(IBookingDAO bookingDAO) {
        this.bookingDAO = bookingDAO;
    }

    @Override
    public void addBooking(Booking booking) {
        if (booking.getStatus() == null || booking.getStatus().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El estado de la reserva no puede estar vacío.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }
        bookingDAO.addBooking(booking);
    }

    @Override
    public Booking getBookingById(int id) {
        return bookingDAO.getBookingById(id);
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingDAO.getAllBookings();
    }

    @Override
    public void updateBooking(Booking booking) {
        bookingDAO.updateBooking(booking);
    }

    @Override
    public void deleteBooking(int id) {
        bookingDAO.deleteBooking(id);
    }

    /**
     * saveBookingState (Patrón Memento):
     * Delega la creación del memento al objeto Booking (Originator).
     * @param booking La reserva cuyo estado se quiere guardar.
     * @return Un BookingMemento que representa el estado actual de la reserva.
     */
    @Override
    public BookingMemento saveBookingState(Booking booking) {
        return booking.createMemento();
    }

    /**
     * restoreBookingState (Patrón Memento):
     * Delega la restauración del estado al objeto Booking (Originator).
     * @param booking La reserva a la que se le restaurará el estado.
     * @param memento El memento con el estado a restaurar.
     */
    @Override
    public void restoreBookingState(Booking booking, BookingMemento memento) {
        booking.restoreFromMemento(memento);
        bookingDAO.updateBooking(booking); // Persistir el estado restaurado en la DB
        JOptionPane.showMessageDialog(null, "Estado de la reserva restaurado a: " + booking.getStatus(), "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }
}
