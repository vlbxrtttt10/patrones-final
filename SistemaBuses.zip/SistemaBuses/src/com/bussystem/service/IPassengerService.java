package com.bussystem.service;

import com.bussystem.model.Passenger;
import java.util.List;

public interface IPassengerService {
    void addPassenger(Passenger passenger);
    Passenger getPassengerById(int id);
    List<Passenger> getAllPassengers();
    void updatePassenger(Passenger passenger);
    void deletePassenger(int id);
}
