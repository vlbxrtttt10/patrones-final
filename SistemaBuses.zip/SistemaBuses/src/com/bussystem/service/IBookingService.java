package com.bussystem.service;

import com.bussystem.model.Booking;
import com.bussystem.patterns.behavioral.memento.BookingMemento;
import java.util.List;

public interface IBookingService {
    void addBooking(Booking booking);
    Booking getBookingById(int id);
    List<Booking> getAllBookings();
    void updateBooking(Booking booking);
    void deleteBooking(int id);
    
    // Métodos para Memento
    BookingMemento saveBookingState(Booking booking);
    void restoreBookingState(Booking booking, BookingMemento memento);
}
