package com.bussystem.service;

import com.bussystem.dao.ITicketDAO;
import com.bussystem.model.ITicket;
import java.util.List;
import javax.swing.JOptionPane;

public class TicketService implements ITicketService {
    private ITicketDAO ticketDAO;

    public TicketService(ITicketDAO ticketDAO) {
        this.ticketDAO = ticketDAO;
    }

    @Override
    public void addTicket(ITicket ticket) {
        if (ticket.getSeatNumber() == null || ticket.getSeatNumber().isEmpty()) {
            JOptionPane.showMessageDialog(null, "El número de asiento no puede estar vacío.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }
        ticketDAO.addTicket(ticket);
    }

    @Override
    public ITicket getTicketById(int id) {
        return ticketDAO.getTicketById(id);
    }

    @Override
    public List<ITicket> getAllTickets() {
        return ticketDAO.getAllTickets();
    }

    @Override
    public void updateTicket(ITicket ticket) {
        ticketDAO.updateTicket(ticket);
    }

    @Override
    public void deleteTicket(int id) {
        ticketDAO.deleteTicket(id);
    }
}
