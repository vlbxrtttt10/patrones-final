package com.bussystem.service;

import com.bussystem.model.ITicket;
import java.util.List;

public interface ITicketService {
    void addTicket(ITicket ticket);
    ITicket getTicketById(int id);
    List<ITicket> getAllTickets();
    void updateTicket(ITicket ticket);
    void deleteTicket(int id);
}
