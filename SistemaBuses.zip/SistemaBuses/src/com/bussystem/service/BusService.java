package com.bussystem.service;

import com.bussystem.dao.IBusDAO;
import com.bussystem.model.Bus;
import com.bussystem.patterns.behavioral.state.AvailableState;
import com.bussystem.patterns.behavioral.state.EnRouteState;
import com.bussystem.patterns.behavioral.state.MaintenanceState;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * BusService (Principio S - Single Responsibility y D - Dependency Inversion):
 * Principio S: Contiene la lógica de negocio para la gestión de buses.
 * Principio D: Depende de la abstracción IBusDAO, no de la implementación concreta BusDAOImpl.
 * Esto permite cambiar la implementación del DAO sin afectar la lógica de negocio del servicio.
 */
public class BusService implements IBusService {
    private IBusDAO busDAO;

    // Inyección de dependencia a través del constructor (Principio D)
    public BusService(IBusDAO busDAO) {
        this.busDAO = busDAO;
    }

    @Override
    public void addBus(Bus bus) {
        // Aquí podría haber lógica de negocio adicional antes de guardar
        if (bus.getCapacity() <= 0) {
            JOptionPane.showMessageDialog(null, "La capacidad del bus debe ser mayor a 0.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }
        busDAO.addBus(bus);
    }

    @Override
    public Bus getBusById(int id) {
        return busDAO.getBusById(id);
    }

    @Override
    public List<Bus> getAllBuses() {
        return busDAO.getAllBuses();
    }

    @Override
    public void updateBus(Bus bus) {
        // Lógica de negocio antes de actualizar
        busDAO.updateBus(bus);
    }

    @Override
    public void deleteBus(int id) {
        // Lógica de negocio antes de eliminar (ej. verificar si tiene reservas activas)
        busDAO.deleteBus(id);
    }

    /**
     * changeBusState (Patrón State):
     * Delega el cambio de estado al objeto Bus, que a su vez usa su objeto de estado actual.
     * Principio O (Open/Closed): Si se añade un nuevo estado, no es necesario modificar este método.
     */
    @Override
    public void changeBusState(Bus bus, String newState) {
        switch (newState) {
            case "Available":
                bus.setState(new AvailableState());
                break;
            case "EnRoute":
                bus.setState(new EnRouteState());
                break;
            case "Maintenance":
                bus.setState(new MaintenanceState());
                break;
            default:
                JOptionPane.showMessageDialog(null, "Estado de bus inválido: " + newState, "Error", JOptionPane.ERROR_MESSAGE);
                return;
        }
        busDAO.updateBus(bus); // Persistir el nuevo estado en la DB
        JOptionPane.showMessageDialog(null, "Estado del bus " + bus.getPlateNumber() + " cambiado a " + newState, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }
}
