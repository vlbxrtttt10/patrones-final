package com.bussystem.service;

import com.bussystem.dao.IRouteDAO;
import com.bussystem.model.Route;
import java.util.List;
import javax.swing.JOptionPane;

public class RouteService implements IRouteService {
    private IRouteDAO routeDAO;

    public RouteService(IRouteDAO routeDAO) {
        this.routeDAO = routeDAO;
    }

    @Override
    public void addRoute(Route route) {
        if (route.getPriceUsd() <= 0) {
            JOptionPane.showMessageDialog(null, "El precio de la ruta debe ser mayor a 0.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }
        routeDAO.addRoute(route);
    }

    @Override
    public Route getRouteById(int id) {
        return routeDAO.getRouteById(id);
    }

    @Override
    public List<Route> getAllRoutes() {
        return routeDAO.getAllRoutes();
    }

    @Override
    public void updateRoute(Route route) {
        routeDAO.updateRoute(route);
    }

    @Override
    public void deleteRoute(int id) {
        routeDAO.deleteRoute(id);
    }
}
