package com.bussystem.service;

import com.bussystem.dao.IPassengerDAO;
import com.bussystem.model.Passenger;
import java.util.List;
import javax.swing.JOptionPane;

public class PassengerService implements IPassengerService {
    private IPassengerDAO passengerDAO;

    public PassengerService(IPassengerDAO passengerDAO) {
        this.passengerDAO = passengerDAO;
    }

    @Override
    public void addPassenger(Passenger passenger) {
        if (passenger.getEmail() == null || !passenger.getEmail().contains("@")) {
            JOptionPane.showMessageDialog(null, "Email de pasajero inválido.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }
        passengerDAO.addPassenger(passenger);
    }

    @Override
    public Passenger getPassengerById(int id) {
        return passengerDAO.getPassengerById(id);
    }

    @Override
    public List<Passenger> getAllPassengers() {
        return passengerDAO.getAllPassengers();
    }

    @Override
    public void updatePassenger(Passenger passenger) {
        passengerDAO.updatePassenger(passenger);
    }

    @Override
    public void deletePassenger(int id) {
        passengerDAO.deletePassenger(id);
    }
}
