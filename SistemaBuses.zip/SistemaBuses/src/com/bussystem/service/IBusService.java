package com.bussystem.service;

import com.bussystem.model.Bus;
import java.util.List;

/**
 * IBusService (Principio I - Interface Segregation y D - Dependency Inversion):
 * Principio I: Define las operaciones de negocio relacionadas con los buses.
 * Principio D: Los módulos de alto nivel (ej. UI, Facade) dependerán de esta abstracción.
 */
public interface IBusService {
    void addBus(Bus bus);
    Bus getBusById(int id);
    List<Bus> getAllBuses();
    void updateBus(Bus bus);
    void deleteBus(int id);
    void changeBusState(Bus bus, String newState); // Lógica de negocio para cambiar estado
}
