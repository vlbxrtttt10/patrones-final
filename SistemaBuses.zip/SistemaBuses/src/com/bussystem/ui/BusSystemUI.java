package com.bussystem.ui;

import com.bussystem.patterns.structural.BusSystemFacade;
import javax.swing.JOptionPane;
import java.util.InputMismatchException;

/**
 * BusSystemUI (Principio S - Single Responsibility):
 * Esta clase es responsable únicamente de la interacción con el usuario a través de JOptionPane.
 * No contiene lógica de negocio ni de persistencia.
 * Depende de la Facade para realizar operaciones.
 */
public class BusSystemUI {
    private BusSystemFacade facade;

    public BusSystemUI(BusSystemFacade facade) {
        this.facade = facade;
    }

    public void start() {
        int choice;
        do {
            String menu = "--- Sistema de Gestión de Buses ---\n"
                        + "1. Gestión de Buses\n"
                        + "2. Gestión de Rutas\n"
                        + "3. Gestión de Pasajeros\n"
                        + "4. Gestión de Boletos y Reservas\n"
                        + "0. Salir";
            String input = JOptionPane.showInputDialog(null, menu, "Menú Principal", JOptionPane.PLAIN_MESSAGE);
            choice = parseIntegerInput(input);

            switch (choice) {
                case 1:
                    manageBuses();
                    break;
                case 2:
                    manageRoutes();
                    break;
                case 3:
                    managePassengers();
                    break;
                case 4:
                    manageTicketsAndBookings();
                    break;
                case 0:
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema. ¡Hasta pronto!", "Adiós", JOptionPane.INFORMATION_MESSAGE);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida. Intente de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (choice != 0);
    }

    private void manageBuses() {
        int choice;
        do {
            String menu = "--- Gestión de Buses ---\n"
                        + "1. Añadir Bus\n"
                        + "2. Listar Buses\n"
                        + "3. Cambiar Estado de Bus\n"
                        + "0. Volver al Menú Principal";
            String input = JOptionPane.showInputDialog(null, menu, "Gestión de Buses", JOptionPane.PLAIN_MESSAGE);
            choice = parseIntegerInput(input);

            switch (choice) {
                case 1:
                    addBus();
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, facade.listAllBuses(), "Lista de Buses", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 3:
                    changeBusState();
                    break;
                case 0:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida. Intente de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (choice != 0);
    }

    private void addBus() {
        String plateNumber = JOptionPane.showInputDialog("Ingrese número de placa:");
        int capacity = parseIntegerInput(JOptionPane.showInputDialog("Ingrese capacidad:"));
        String model = JOptionPane.showInputDialog("Ingrese modelo:");
        if (plateNumber != null && !plateNumber.isEmpty() && capacity > 0 && model != null && !model.isEmpty()) {
            facade.addBus(plateNumber, capacity, model);
        } else {
            JOptionPane.showMessageDialog(null, "Datos de bus inválidos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void changeBusState() {
        int busId = parseIntegerInput(JOptionPane.showInputDialog("Ingrese ID del bus para cambiar estado:"));
        if (busId == -1) return;

        String[] possibleStates = {"Available", "EnRoute", "Maintenance"};
        String newState = (String) JOptionPane.showInputDialog(null,
                "Seleccione el nuevo estado:",
                "Cambiar Estado de Bus",
                JOptionPane.QUESTION_MESSAGE,
                null,
                possibleStates,
                possibleStates[0]);

        if (newState != null) {
            facade.updateBusStatus(busId, newState);
        }
    }

    private void manageRoutes() {
        int choice;
        do {
            String menu = "--- Gestión de Rutas ---\n"
                        + "1. Añadir Ruta\n"
                        + "2. Listar Rutas\n"
                        + "0. Volver al Menú Principal";
            String input = JOptionPane.showInputDialog(null, menu, "Gestión de Rutas", JOptionPane.PLAIN_MESSAGE);
            choice = parseIntegerInput(input);

            switch (choice) {
                case 1:
                    addRoute();
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, facade.listAllRoutes(), "Lista de Rutas", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 0:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida. Intente de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (choice != 0);
    }

    private void addRoute() {
        String origin = JOptionPane.showInputDialog("Ingrese origen:");
        String destination = JOptionPane.showInputDialog("Ingrese destino:");
        double distance = parseDoubleInput(JOptionPane.showInputDialog("Ingrese distancia (km):"));
        double price = parseDoubleInput(JOptionPane.showInputDialog("Ingrese precio (USD):"));
        if (origin != null && !origin.isEmpty() && destination != null && !destination.isEmpty() && distance >= 0 && price > 0) {
            facade.addRoute(origin, destination, distance, price);
        } else {
            JOptionPane.showMessageDialog(null, "Datos de ruta inválidos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void managePassengers() {
        int choice;
        do {
            String menu = "--- Gestión de Pasajeros ---\n"
                        + "1. Añadir Pasajero\n"
                        + "2. Listar Pasajeros\n"
                        + "0. Volver al Menú Principal";
            String input = JOptionPane.showInputDialog(null, menu, "Gestión de Pasajeros", JOptionPane.PLAIN_MESSAGE);
            choice = parseIntegerInput(input);

            switch (choice) {
                case 1:
                    addPassenger();
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, facade.listAllPassengers(), "Lista de Pasajeros", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 0:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida. Intente de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (choice != 0);
    }

    private void addPassenger() {
        String name = JOptionPane.showInputDialog("Ingrese nombre del pasajero:");
        String email = JOptionPane.showInputDialog("Ingrese email del pasajero:");
        String phone = JOptionPane.showInputDialog("Ingrese teléfono del pasajero:");
        if (name != null && !name.isEmpty() && email != null && !email.isEmpty()) {
            facade.addPassenger(name, email, phone);
        } else {
            JOptionPane.showMessageDialog(null, "Datos de pasajero inválidos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void manageTicketsAndBookings() {
        int choice;
        do {
            String menu = "--- Gestión de Boletos y Reservas ---\n"
                        + "1. Crear Reserva\n"
                        + "2. Listar Reservas\n"
                        + "3. Cancelar Reserva\n"
                        + "4. Restaurar Reserva (Memento)\n"
                        + "0. Volver al Menú Principal";
            String input = JOptionPane.showInputDialog(null, menu, "Gestión de Boletos y Reservas", JOptionPane.PLAIN_MESSAGE);
            choice = parseIntegerInput(input);

            switch (choice) {
                case 1:
                    createBooking();
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, facade.listAllBookings(), "Lista de Reservas", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 3:
                    cancelBooking();
                    break;
                case 4:
                    restoreBooking();
                    break;
                case 0:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida. Intente de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (choice != 0);
    }

    private void createBooking() {
        int routeId = parseIntegerInput(JOptionPane.showInputDialog("Ingrese ID de la ruta:"));
        int busId = parseIntegerInput(JOptionPane.showInputDialog("Ingrese ID del bus:"));
        int passengerId = parseIntegerInput(JOptionPane.showInputDialog("Ingrese ID del pasajero:"));
        String seatNumber = JOptionPane.showInputDialog("Ingrese número de asiento:");

        String[] ticketTypes = {"Standard", "VIP"};
        String ticketType = (String) JOptionPane.showInputDialog(null,
                "Seleccione tipo de boleto:",
                "Tipo de Boleto",
                JOptionPane.QUESTION_MESSAGE,
                null,
                ticketTypes,
                ticketTypes[0]);

        if (ticketType == null) return; // User cancelled

        boolean addLuggage = false;
        if ("Standard".equalsIgnoreCase(ticketType)) { // Solo para boletos estándar
            int confirmLuggage = JOptionPane.showConfirmDialog(null, "¿Desea añadir tarifa por equipaje?", "Equipaje", JOptionPane.YES_NO_OPTION);
            addLuggage = (confirmLuggage == JOptionPane.YES_OPTION);
        }
        
        boolean addWifi = false;
        if (!"VIP".equalsIgnoreCase(ticketType)) { // VIP ya incluye WiFi
            int confirmWifi = JOptionPane.showConfirmDialog(null, "¿Desea añadir acceso a WiFi?", "WiFi", JOptionPane.YES_NO_OPTION);
            addWifi = (confirmWifi == JOptionPane.YES_OPTION);
        }

        if (routeId != -1 && busId != -1 && passengerId != -1 && seatNumber != null && !seatNumber.isEmpty()) {
            facade.createBooking(routeId, busId, passengerId, seatNumber, ticketType, addLuggage, addWifi);
        } else {
            JOptionPane.showMessageDialog(null, "Datos de reserva inválidos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cancelBooking() {
        int bookingId = parseIntegerInput(JOptionPane.showInputDialog("Ingrese ID de la reserva a cancelar:"));
        if (bookingId != -1) {
            facade.cancelBooking(bookingId);
        }
    }

    private void restoreBooking() {
        int bookingId = parseIntegerInput(JOptionPane.showInputDialog("Ingrese ID de la reserva a restaurar:"));
        if (bookingId != -1) {
            facade.restoreBooking(bookingId);
        }
    }

    private int parseIntegerInput(String input) {
        if (input == null) return -1; // User cancelled
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Por favor, ingrese un número entero.", "Error de Entrada", JOptionPane.ERROR_MESSAGE);
            return -1;
        }
    }

    private double parseDoubleInput(String input) {
        if (input == null) return -1.0; // User cancelled
        try {
            return Double.parseDouble(input);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Por favor, ingrese un número decimal.", "Error de Entrada", JOptionPane.ERROR_MESSAGE);
            return -1.0;
        }
    }
}
