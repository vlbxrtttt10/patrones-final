package com.bussystem.dao;

import com.bussystem.model.Booking;
import java.util.List;

/**
 * IBookingDAO (Principio I - Interface Segregation y D - Dependency Inversion):
 * Principio I (Interface Segregation): Define solo las operaciones CRUD para la entidad Booking.
 * Principio D (Dependency Inversion): Los servicios dependerán de esta abstracción.
 */
public interface IBookingDAO {
    void addBooking(Booking booking);
    Booking getBookingById(int id);
    List<Booking> getAllBookings();
    void updateBooking(Booking booking);
    void deleteBooking(int id);
}
