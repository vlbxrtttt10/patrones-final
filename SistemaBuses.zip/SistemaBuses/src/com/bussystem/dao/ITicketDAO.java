package com.bussystem.dao;

import com.bussystem.model.ITicket;
import java.util.List;

/**
 * ITicketDAO (Principio I - Interface Segregation y D - Dependency Inversion):
 * Principio I (Interface Segregation): Define solo las operaciones CRUD para la entidad Ticket.
 * Principio D (Dependency Inversion): Los servicios dependerán de esta abstracción.
 */
public interface ITicketDAO {
    void addTicket(ITicket ticket);
    ITicket getTicketById(int id);
    List<ITicket> getAllTickets();
    void updateTicket(ITicket ticket);
    void deleteTicket(int id);
}
