package com.bussystem.dao;

import com.bussystem.model.Passenger;
import java.util.List;

/**
 * IPassengerDAO (Principio I - Interface Segregation y D - Dependency Inversion):
 * Principio I (Interface Segregation): Define solo las operaciones CRUD para la entidad Passenger.
 * Principio D (Dependency Inversion): Los servicios dependerán de esta abstracción.
 */
public interface IPassengerDAO {
    void addPassenger(Passenger passenger);
    Passenger getPassengerById(int id);
    List<Passenger> getAllPassengers();
    void updatePassenger(Passenger passenger);
    void deletePassenger(int id);
}
