package com.bussystem.dao;

import com.bussystem.model.Bus;
import java.util.List;

/**
 * IBusDAO (Principio I - Interface Segregation y D - Dependency Inversion):
 * Principio I (Interface Segregation): Esta interfaz define solo las operaciones CRUD para la entidad Bus.
 * No contiene métodos para otras entidades, evitando interfaces "gordas".
 * Principio D (Dependency Inversion): Los módulos de alto nivel (servicios) dependerán de esta abstracción,
 * no de una implementación concreta de DAO.
 */
public interface IBusDAO {
    void addBus(Bus bus);
    Bus getBusById(int id);
    List<Bus> getAllBuses();
    void updateBus(Bus bus);
    void deleteBus(int id);
}
