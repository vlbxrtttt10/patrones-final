package com.bussystem.dao;

import com.bussystem.model.Bus;
import com.bussystem.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * BusDAOImpl (Principio S - Single Responsibility):
 * Esta clase es responsable únicamente de las operaciones de persistencia (CRUD) para la entidad Bus.
 * No contiene lógica de negocio ni de interfaz de usuario.
 */
public class BusDAOImpl implements IBusDAO {
    private Connection connection;

    public BusDAOImpl() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }

    @Override
    public void addBus(Bus bus) {
        String sql = "INSERT INTO buses (plate_number, capacity, model, status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, bus.getPlateNumber());
            pstmt.setInt(2, bus.getCapacity());
            pstmt.setString(3, bus.getModel());
            pstmt.setString(4, bus.getStatus());
            pstmt.executeUpdate();

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    bus.setId(generatedKeys.getInt(1));
                }
            }
            JOptionPane.showMessageDialog(null, "Bus agregado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar bus: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    @Override
    public Bus getBusById(int id) {
        String sql = "SELECT * FROM buses WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Bus(
                        rs.getInt("id"),
                        rs.getString("plate_number"),
                        rs.getInt("capacity"),
                        rs.getString("model"),
                        rs.getString("status")
                    );
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener bus por ID: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Bus> getAllBuses() {
        List<Bus> buses = new ArrayList<>();
        String sql = "SELECT * FROM buses";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                buses.add(new Bus(
                    rs.getInt("id"),
                    rs.getString("plate_number"),
                    rs.getInt("capacity"),
                    rs.getString("model"),
                    rs.getString("status")
                ));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener todos los buses: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return buses;
    }

    @Override
    public void updateBus(Bus bus) {
        String sql = "UPDATE buses SET plate_number = ?, capacity = ?, model = ?, status = ? WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, bus.getPlateNumber());
            pstmt.setInt(2, bus.getCapacity());
            pstmt.setString(3, bus.getModel());
            pstmt.setString(4, bus.getStatus());
            pstmt.setInt(5, bus.getId());
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Bus actualizado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar bus: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    @Override
    public void deleteBus(int id) {
        String sql = "DELETE FROM buses WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Bus eliminado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar bus: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
