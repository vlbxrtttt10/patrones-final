package com.bussystem.dao;

import com.bussystem.model.ITicket;
import com.bussystem.model.StandardTicket;
import com.bussystem.model.VIPTicket;
import com.bussystem.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class TicketDAOImpl implements ITicketDAO {
    private Connection connection;

    public TicketDAOImpl() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }

    @Override
    public void addTicket(ITicket ticket) {
        String sql = "INSERT INTO tickets (route_id, bus_id, passenger_id, seat_number, base_price, final_price, ticket_type, has_luggage, has_wifi, booking_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, ticket.getRouteId());
            pstmt.setInt(2, ticket.getBusId());
            pstmt.setInt(3, ticket.getPassengerId());
            pstmt.setString(4, ticket.getSeatNumber());
            pstmt.setDouble(5, ticket.getBasePrice());
            pstmt.setDouble(6, ticket.getFinalPrice());
            pstmt.setString(7, ticket.getTicketType());
            pstmt.setBoolean(8, ticket.hasLuggage());
            pstmt.setBoolean(9, ticket.hasWifi());
            pstmt.setString(10, ticket.getBookingDate());
            pstmt.executeUpdate();

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    ticket.setId(generatedKeys.getInt(1));
                }
            }
            JOptionPane.showMessageDialog(null, "Boleto agregado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar boleto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    @Override
    public ITicket getTicketById(int id) {
        String sql = "SELECT * FROM tickets WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String ticketType = rs.getString("ticket_type");
                    if ("Standard".equals(ticketType)) {
                        return new StandardTicket(
                            rs.getInt("id"),
                            rs.getInt("route_id"),
                            rs.getInt("bus_id"),
                            rs.getInt("passenger_id"),
                            rs.getString("seat_number"),
                            rs.getDouble("base_price"),
                            rs.getDouble("final_price"),
                            rs.getString("booking_date")
                        );
                    } else if ("VIP".equals(ticketType)) {
                        return new VIPTicket(
                            rs.getInt("id"),
                            rs.getInt("route_id"),
                            rs.getInt("bus_id"),
                            rs.getInt("passenger_id"),
                            rs.getString("seat_number"),
                            rs.getDouble("base_price"),
                            rs.getDouble("final_price"),
                            rs.getString("booking_date")
                        );
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener boleto por ID: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<ITicket> getAllTickets() {
        List<ITicket> tickets = new ArrayList<>();
        String sql = "SELECT * FROM tickets";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                String ticketType = rs.getString("ticket_type");
                if ("Standard".equals(ticketType)) {
                    tickets.add(new StandardTicket(
                        rs.getInt("id"),
                        rs.getInt("route_id"),
                        rs.getInt("bus_id"),
                        rs.getInt("passenger_id"),
                        rs.getString("seat_number"),
                        rs.getDouble("base_price"),
                        rs.getDouble("final_price"),
                        rs.getString("booking_date")
                    ));
                } else if ("VIP".equals(ticketType)) {
                    tickets.add(new VIPTicket(
                        rs.getInt("id"),
                        rs.getInt("route_id"),
                        rs.getInt("bus_id"),
                        rs.getInt("passenger_id"),
                        rs.getString("seat_number"),
                        rs.getDouble("base_price"),
                        rs.getDouble("final_price"),
                        rs.getString("booking_date")
                    ));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener todos los boletos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return tickets;
    }

    @Override
    public void updateTicket(ITicket ticket) {
        String sql = "UPDATE tickets SET route_id = ?, bus_id = ?, passenger_id = ?, seat_number = ?, base_price = ?, final_price = ?, ticket_type = ?, has_luggage = ?, has_wifi = ? WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, ticket.getRouteId());
            pstmt.setInt(2, ticket.getBusId());
            pstmt.setInt(3, ticket.getPassengerId());
            pstmt.setString(4, ticket.getSeatNumber());
            pstmt.setDouble(5, ticket.getBasePrice());
            pstmt.setDouble(6, ticket.getFinalPrice());
            pstmt.setString(7, ticket.getTicketType());
            pstmt.setBoolean(8, ticket.hasLuggage());
            pstmt.setBoolean(9, ticket.hasWifi());
            pstmt.setInt(10, ticket.getId());
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Boleto actualizado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar boleto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    @Override
    public void deleteTicket(int id) {
        String sql = "DELETE FROM tickets WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Boleto eliminado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar boleto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
