package com.bussystem.dao;

import com.bussystem.model.Route;
import java.util.List;

/**
 * IRouteDAO (Principio I - Interface Segregation y D - Dependency Inversion):
 * Principio I (Interface Segregation): Define solo las operaciones CRUD para la entidad Route.
 * Principio D (Dependency Inversion): Los servicios dependerán de esta abstracción.
 */
public interface IRouteDAO {
    void addRoute(Route route);
    Route getRouteById(int id);
    List<Route> getAllRoutes();
    void updateRoute(Route route);
    void deleteRoute(int id);
}
