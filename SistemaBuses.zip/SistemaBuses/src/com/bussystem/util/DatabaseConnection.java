package com.bussystem.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * DatabaseConnection (Patrón Singleton):
 * Asegura que solo exista una instancia de la conexión a la base de datos en toda la aplicación.
 * Esto es crucial para gestionar eficientemente los recursos de la base de datos y evitar múltiples conexiones innecesarias.
 * Principio S (Single Responsibility): Esta clase es únicamente responsable de gestionar la conexión a la base de datos.
 */
public class DatabaseConnection {
    private static DatabaseConnection instance;
    private Connection connection;

    private final String URL = "jdbc:mysql://localhost:3306/bus_system";
    private final String USER = "root"; // Cambia si tu usuario de MySQL es diferente
    private final String PASSWORD = ""; // Cambia si tu contraseña de MySQL es diferente

    // Constructor privado para evitar instanciación externa
    private DatabaseConnection() {
        try {
            // Cargar el driver JDBC de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión a la base de datos establecida.");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error: Driver JDBC de MySQL no encontrado.\nAsegúrate de tener el JAR en la carpeta lib y añadido al classpath.", "Error de Conexión", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e.getMessage(), "Error de Conexión", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    // Método estático para obtener la única instancia de la clase
    public static DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        }
        return instance;
    }

    // Método para obtener la conexión
    public Connection getConnection() {
        try {
            // Verificar si la conexión está cerrada o es inválida y reconectar si es necesario
            if (connection == null || connection.isClosed() || !connection.isValid(5)) {
                System.out.println("Reconectando a la base de datos...");
                this.connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Reconexión exitosa.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener/validar la conexión: " + e.getMessage(), "Error de Conexión", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return connection;
    }

    // Método para cerrar la conexión (opcional, ya que Singleton mantiene la conexión abierta)
    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Conexión a la base de datos cerrada.");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + e.getMessage(), "Error de Conexión", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }
}
