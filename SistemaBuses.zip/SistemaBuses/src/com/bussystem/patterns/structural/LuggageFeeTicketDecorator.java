package com.bussystem.patterns.structural;

import com.bussystem.model.ITicket;

/**
 * LuggageFeeTicketDecorator (Patrón Decorator):
 * Añade la funcionalidad de una tarifa por equipaje a un boleto existente.
 */
public class LuggageFeeTicketDecorator extends TicketDecorator {
    private static final double LUGGAGE_FEE = 10.00;

    public LuggageFeeTicketDecorator(ITicket decoratedTicket) {
        super(decoratedTicket);
        // Actualizar el precio final y la bandera de equipaje
        decoratedTicket.setFinalPrice(decoratedTicket.getFinalPrice() + LUGGAGE_FEE);
        decoratedTicket.setHasLuggage(true);
    }

    @Override
    public String getDescription() {
        return decoratedTicket.getDescription() + " + Tarifa de Equipaje";
    }
}
