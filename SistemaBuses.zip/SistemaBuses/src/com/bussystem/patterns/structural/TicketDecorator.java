package com.bussystem.patterns.structural;

import com.bussystem.model.ITicket;

/**
 * TicketDecorator (Patrón Decorator):
 * Clase abstracta base para todos los decoradores de boletos.
 * Mantiene una referencia al objeto ITicket que está decorando.
 * Principio O (Open/Closed): Permite añadir nuevas funcionalidades a los boletos
 * dinámicamente sin modificar sus clases originales.
 */
public abstract class TicketDecorator implements ITicket {
    protected ITicket decoratedTicket;

    public TicketDecorator(ITicket decoratedTicket) {
        this.decoratedTicket = decoratedTicket;
    }

    // Delegar todos los métodos al boleto decorado
    @Override public int getId() { return decoratedTicket.getId(); }
    @Override public void setId(int id) { decoratedTicket.setId(id); }
    @Override public int getRouteId() { return decoratedTicket.getRouteId(); }
    @Override public void setRouteId(int routeId) { decoratedTicket.setRouteId(routeId); }
    @Override public int getBusId() { return decoratedTicket.getBusId(); }
    @Override public void setBusId(int busId) { decoratedTicket.setBusId(busId); }
    @Override public int getPassengerId() { return decoratedTicket.getPassengerId(); }
    @Override public void setPassengerId(int passengerId) { decoratedTicket.setPassengerId(passengerId); }
    @Override public String getSeatNumber() { return decoratedTicket.getSeatNumber(); }
    @Override public void setSeatNumber(String seatNumber) { decoratedTicket.setSeatNumber(seatNumber); }
    @Override public double getBasePrice() { return decoratedTicket.getBasePrice(); }
    @Override public void setBasePrice(double basePrice) { decoratedTicket.setBasePrice(basePrice); }
    @Override public double getFinalPrice() { return decoratedTicket.getFinalPrice(); }
    @Override public void setFinalPrice(double finalPrice) { decoratedTicket.setFinalPrice(finalPrice); }
    @Override public String getTicketType() { return decoratedTicket.getTicketType(); }
    @Override public void setTicketType(String ticketType) { decoratedTicket.setTicketType(ticketType); }
    @Override public boolean hasLuggage() { return decoratedTicket.hasLuggage(); }
    @Override public void setHasLuggage(boolean hasLuggage) { decoratedTicket.setHasLuggage(hasLuggage); }
    @Override public boolean hasWifi() { return decoratedTicket.hasWifi(); }
    @Override public void setHasWifi(boolean hasWifi) { decoratedTicket.setHasWifi(hasWifi); }
    @Override public String getBookingDate() { return decoratedTicket.getBookingDate(); }
    @Override public void setBookingDate(String bookingDate) { decoratedTicket.setBookingDate(bookingDate); }

    // El método getDescription() y getFinalPrice() serán sobrescritos por los decoradores concretos
    @Override
    public abstract String getDescription();
}
