package com.bussystem.patterns.structural;

import com.bussystem.dao.*;
import com.bussystem.model.*;
import com.bussystem.patterns.creational.TicketFactory;
import com.bussystem.patterns.behavioral.memento.BookingCaretaker;
import com.bussystem.patterns.behavioral.memento.BookingMemento;
import com.bussystem.service.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * BusSystemFacade (Patrón Facade):
 * Proporciona una interfaz simplificada a un subsistema complejo de clases (DAOs y Servicios).
 * La UI interactúa solo con esta Facade, sin necesidad de conocer la complejidad interna.
 * Principio S (Single Responsibility): Su única responsabilidad es simplificar la interacción con el subsistema.
 * Principio D (Dependency Inversion): Depende de las interfaces de servicio, no de sus implementaciones concretas.
 */
public class BusSystemFacade {
    private IBusService busService;
    private IRouteService routeService;
    private IPassengerService passengerService;
    private ITicketService ticketService;
    private IBookingService bookingService;
    private BookingCaretaker bookingCaretaker; // Para el patrón Memento

    // Inyección de dependencias para los servicios (Principio D)
    public BusSystemFacade(IBusService busService, IRouteService routeService, IPassengerService passengerService, ITicketService ticketService, IBookingService bookingService) {
        this.busService = busService;
        this.routeService = routeService;
        this.passengerService = passengerService;
        this.ticketService = ticketService;
        this.bookingService = bookingService;
        this.bookingCaretaker = new BookingCaretaker(); // Inicializar Caretaker
    }

    // --- Métodos simplificados para la UI ---

    // Gestión de Buses
    public void addBus(String plateNumber, int capacity, String model) {
        Bus bus = new Bus(plateNumber, capacity, model);
        busService.addBus(bus);
    }

    public String listAllBuses() {
        List<Bus> buses = busService.getAllBuses();
        if (buses.isEmpty()) return "No hay buses registrados.";
        StringBuilder sb = new StringBuilder("--- Lista de Buses ---\n");
        for (Bus bus : buses) {
            sb.append(bus.toString()).append("\n");
        }
        return sb.toString();
    }

    public void updateBusStatus(int busId, String newStatus) {
        Bus bus = busService.getBusById(busId);
        if (bus != null) {
            busService.changeBusState(bus, newStatus);
        } else {
            JOptionPane.showMessageDialog(null, "Bus no encontrado con ID: " + busId, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Gestión de Rutas
    public void addRoute(String origin, String destination, double distanceKm, double priceUsd) {
        Route route = new Route(origin, destination, distanceKm, priceUsd);
        routeService.addRoute(route);
    }

    public String listAllRoutes() {
        List<Route> routes = routeService.getAllRoutes();
        if (routes.isEmpty()) return "No hay rutas registradas.";
        StringBuilder sb = new StringBuilder("--- Lista de Rutas ---\n");
        for (Route route : routes) {
            sb.append(route.toString()).append("\n");
        }
        return sb.toString();
    }

    // Gestión de Pasajeros
    public void addPassenger(String name, String email, String phone) {
        Passenger passenger = new Passenger(name, email, phone);
        passengerService.addPassenger(passenger);
    }

    public String listAllPassengers() {
        List<Passenger> passengers = passengerService.getAllPassengers();
        if (passengers.isEmpty()) return "No hay pasajeros registrados.";
        StringBuilder sb = new StringBuilder("--- Lista de Pasajeros ---\n");
        for (Passenger passenger : passengers) {
            sb.append(passenger.toString()).append("\n");
        }
        return sb.toString();
    }

    // Gestión de Boletos y Reservas (combinado para simplificar la UI)
    public void createBooking(int routeId, int busId, int passengerId, String seatNumber, String ticketType, boolean addLuggage, boolean addWifi) {
        Route route = routeService.getRouteById(routeId);
        Bus bus = busService.getBusById(busId);
        Passenger passenger = passengerService.getPassengerById(passengerId);

        if (route == null || bus == null || passenger == null) {
            JOptionPane.showMessageDialog(null, "Ruta, Bus o Pasajero no encontrados.", "Error de Creación de Reserva", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!"Available".equals(bus.getStatus())) {
            JOptionPane.showMessageDialog(null, "El bus no está disponible para reservas.", "Error de Creación de Reserva", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Usar Factory Method para crear el boleto base
        ITicket ticket = TicketFactory.createTicket(ticketType, routeId, busId, passengerId, seatNumber, route.getPriceUsd(), LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

        // Usar Decorator para añadir funcionalidades adicionales
        if (addLuggage) {
            ticket = new LuggageFeeTicketDecorator(ticket);
        }
        if (addWifi && !"VIP".equalsIgnoreCase(ticketType)) { // VIP ya incluye WiFi
            ticket = new WiFiTicketDecorator(ticket);
        }

        ticketService.addTicket(ticket); // Guardar el boleto (con sus decoraciones)

        // Crear la reserva
        Booking booking = new Booking(ticket.getId(), "Confirmed");
        bookingService.addBooking(booking);

        // Guardar el estado inicial de la reserva con Memento
        bookingCaretaker.addMemento(booking.getId(), bookingService.saveBookingState(booking));

        JOptionPane.showMessageDialog(null, "Reserva creada exitosamente!\n" + ticket.getDescription() + "\nPrecio Final: US$" + String.format("%.2f", ticket.getFinalPrice()), "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    public String listAllBookings() {
        List<Booking> bookings = bookingService.getAllBookings();
        if (bookings.isEmpty()) return "No hay reservas registradas.";
        StringBuilder sb = new StringBuilder("--- Lista de Reservas ---\n");
        for (Booking booking : bookings) {
            ITicket ticket = ticketService.getTicketById(booking.getTicketId());
            sb.append(booking.toString());
            if (ticket != null) {
                sb.append(", Boleto: ").append(ticket.getDescription()).append(" (ID: ").append(ticket.getId()).append(")");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public void cancelBooking(int bookingId) {
        Booking booking = bookingService.getBookingById(bookingId);
        if (booking != null) {
            // Guardar estado antes de cambiar (para Memento)
            bookingCaretaker.addMemento(booking.getId(), bookingService.saveBookingState(booking));
            booking.setStatus("Cancelled");
            bookingService.updateBooking(booking);
            JOptionPane.showMessageDialog(null, "Reserva " + bookingId + " cancelada.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Reserva no encontrada con ID: " + bookingId, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void restoreBooking(int bookingId) {
        Booking booking = bookingService.getBookingById(bookingId);
        if (booking != null) {
            BookingMemento memento = bookingCaretaker.getMemento(bookingId);
            if (memento != null) {
                bookingService.restoreBookingState(booking, memento);
                JOptionPane.showMessageDialog(null, "Reserva " + bookingId + " restaurada a estado anterior.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "No hay estado guardado para la reserva " + bookingId, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Reserva no encontrada con ID: " + bookingId, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
