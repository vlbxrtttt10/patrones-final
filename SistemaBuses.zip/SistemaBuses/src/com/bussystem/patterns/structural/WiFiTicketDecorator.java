package com.bussystem.patterns.structural;

import com.bussystem.model.ITicket;

/**
 * WiFiTicketDecorator (Patrón Decorator):
 * Añade la funcionalidad de WiFi a un boleto existente.
 */
public class WiFiTicketDecorator extends TicketDecorator {
    private static final double WIFI_FEE = 5.00;

    public WiFiTicketDecorator(ITicket decoratedTicket) {
        super(decoratedTicket);
        // Actualizar el precio final y la bandera de WiFi
        decoratedTicket.setFinalPrice(decoratedTicket.getFinalPrice() + WIFI_FEE);
        decoratedTicket.setHasWifi(true);
    }

    @Override
    public String getDescription() {
        return decoratedTicket.getDescription() + " + Acceso a WiFi";
    }
}
