package com.bussystem.patterns.structural;

import com.bussystem.model.Bus;
import com.bussystem.service.IBusService;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * BusServiceProxy (Patrón Proxy):
 * Actúa como un sustituto o intermediario para un objeto BusService real.
 * Aquí, añade funcionalidad de logging antes y después de las llamadas al servicio.
 * Principio S (Single Responsibility): Su responsabilidad es controlar el acceso y añadir logging.
 * Principio O (Open/Closed): Se puede añadir logging sin modificar la clase BusService original.
 */
public class BusServiceProxy implements IBusService {
    private IBusService realBusService;

    public BusServiceProxy(IBusService realBusService) {
        this.realBusService = realBusService;
    }

    private void log(String message) {
        System.out.println("[PROXY LOG] " + message);
        // En una aplicación real, esto iría a un archivo de log o sistema de monitoreo
    }

    @Override
    public void addBus(Bus bus) {
        log("Intentando añadir bus: " + bus.getPlateNumber());
        realBusService.addBus(bus);
        log("Bus añadido: " + bus.getPlateNumber());
    }

    @Override
    public Bus getBusById(int id) {
        log("Intentando obtener bus con ID: " + id);
        Bus bus = realBusService.getBusById(id);
        if (bus != null) {
            log("Bus obtenido: " + bus.getPlateNumber());
        } else {
            log("Bus no encontrado con ID: " + id);
        }
        return bus;
    }

    @Override
    public List<Bus> getAllBuses() {
        log("Intentando obtener todos los buses.");
        List<Bus> buses = realBusService.getAllBuses();
        log("Obtenidos " + buses.size() + " buses.");
        return buses;
    }

    @Override
    public void updateBus(Bus bus) {
        log("Intentando actualizar bus: " + bus.getPlateNumber());
        realBusService.updateBus(bus);
        log("Bus actualizado: " + bus.getPlateNumber());
    }

    @Override
    public void deleteBus(int id) {
        log("Intentando eliminar bus con ID: " + id);
        realBusService.deleteBus(id);
        log("Bus eliminado con ID: " + id);
    }

    @Override
    public void changeBusState(Bus bus, String newState) {
        log("Intentando cambiar estado del bus " + bus.getPlateNumber() + " a " + newState);
        realBusService.changeBusState(bus, newState);
        log("Estado del bus " + bus.getPlateNumber() + " cambiado a " + newState);
    }
}
