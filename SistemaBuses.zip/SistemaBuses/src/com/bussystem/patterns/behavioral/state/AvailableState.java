package com.bussystem.patterns.behavioral.state;

import com.bussystem.model.Bus;
import javax.swing.JOptionPane;

/**
 * AvailableState (Patrón State):
 * Estado concreto que representa un bus disponible.
 * Define el comportamiento específico cuando el bus está en este estado.
 */
public class AvailableState implements BusState {
    @Override
    public void handleRequest(Bus bus) {
        JOptionPane.showMessageDialog(null, "El bus " + bus.getPlateNumber() + " está disponible para rutas.", "Estado del Bus", JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public String getStatusName() {
        return "Available";
    }
}
