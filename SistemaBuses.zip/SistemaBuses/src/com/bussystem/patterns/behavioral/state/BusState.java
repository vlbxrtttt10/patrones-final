package com.bussystem.patterns.behavioral.state;

import com.bussystem.model.Bus;

/**
 * BusState (Patrón State):
 * Interfaz que define el comportamiento para los diferentes estados de un bus.
 * Principio O (Open/Closed): Nuevos estados pueden ser añadidos implementando esta interfaz
 * sin modificar las clases de estado existentes ni la clase Bus.
 */
public interface BusState {
    void handleRequest(Bus bus);
    String getStatusName();
}
