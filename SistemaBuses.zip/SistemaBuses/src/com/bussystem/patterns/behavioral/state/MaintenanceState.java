package com.bussystem.patterns.behavioral.state;

import com.bussystem.model.Bus;
import javax.swing.JOptionPane;

/**
 * MaintenanceState (Patrón State):
 * Estado concreto que representa un bus en mantenimiento.
 */
public class MaintenanceState implements BusState {
    @Override
    public void handleRequest(Bus bus) {
        JOptionPane.showMessageDialog(null, "El bus " + bus.getPlateNumber() + " está en mantenimiento.", "Estado del Bus", JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public String getStatusName() {
        return "Maintenance";
    }
}
