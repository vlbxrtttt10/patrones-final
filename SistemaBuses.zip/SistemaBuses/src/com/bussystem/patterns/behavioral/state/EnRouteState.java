package com.bussystem.patterns.behavioral.state;

import com.bussystem.model.Bus;
import javax.swing.JOptionPane;

/**
 * EnRouteState (Patrón State):
 * Estado concreto que representa un bus en ruta.
 */
public class EnRouteState implements BusState {
    @Override
    public void handleRequest(Bus bus) {
        JOptionPane.showMessageDialog(null, "El bus " + bus.getPlateNumber() + " está actualmente en ruta.", "Estado del Bus", JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public String getStatusName() {
        return "EnRoute";
    }
}
