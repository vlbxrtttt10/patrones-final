package com.bussystem.patterns.behavioral.memento;

/**
 * BookingMemento (Patrón Memento):
 * Almacena el estado interno de un objeto Booking (Originator) sin exponer su implementación.
 * Principio S (Single Responsibility): Su única responsabilidad es almacenar el estado.
 */
public class BookingMemento {
    private final int id;
    private final int ticketId;
    private final String status;

    public BookingMemento(int id, int ticketId, String status) {
        this.id = id;
        this.ticketId = ticketId;
        this.status = status;
    }

    // Getters para el estado (solo para el Caretaker, no para el cliente externo)
    public int getId() {
        return id;
    }

    public int getTicketId() {
        return ticketId;
    }

    public String getStatus() {
        return status;
    }
}
