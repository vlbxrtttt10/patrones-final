package com.bussystem.patterns.behavioral.memento;

import java.util.HashMap;
import java.util.Map;

/**
 * BookingCaretaker (Patrón Memento):
 * Responsable de guardar y recuperar Mementos.
 * No inspecciona el contenido de los Mementos.
 * Principio S (Single Responsibility): Su única responsabilidad es gestionar los mementos.
 */
public class BookingCaretaker {
    // Usamos un mapa para almacenar mementos por ID de reserva
    private Map<Integer, BookingMemento> mementoMap = new HashMap<>();

    public void addMemento(int bookingId, BookingMemento memento) {
        mementoMap.put(bookingId, memento);
        System.out.println("Memento guardado para reserva ID: " + bookingId);
    }

    public BookingMemento getMemento(int bookingId) {
        System.out.println("Recuperando memento para reserva ID: " + bookingId);
        return mementoMap.get(bookingId);
    }
}
