package com.bussystem.patterns.behavioral.observer;

import java.util.ArrayList;
import java.util.List;

/**
 * BusSubject (Patrón Observer):
 * Clase abstracta que representa el "Sujeto" en el patrón Observer.
 * Mantiene una lista de observadores y los notifica sobre cambios.
 * Principio O (Open/Closed): Permite añadir nuevos observadores sin modificar el Sujeto.
 */
public abstract class BusSubject {
    private List<BusObserver> observers = new ArrayList<>();

    public void addObserver(BusObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(BusObserver observer) {
        observers.remove(observer);
    }

    public void notifyObservers(String message) {
        for (BusObserver observer : observers) {
            observer.update(message);
        }
    }
}
