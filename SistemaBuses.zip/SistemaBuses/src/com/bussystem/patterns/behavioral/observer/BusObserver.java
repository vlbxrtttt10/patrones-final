package com.bussystem.patterns.behavioral.observer;

/**
 * BusObserver (Patrón Observer):
 * Interfaz para los observadores que desean ser notificados sobre cambios en el bus.
 * Principio O (Open/Closed): Nuevos observadores pueden ser añadidos implementando esta interfaz.
 */
public interface BusObserver {
    void update(String message);
}
