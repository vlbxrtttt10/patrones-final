package com.bussystem.patterns.behavioral.observer;

/**
 * BusStatusLogger (Patrón Observer):
 * Observador concreto que simplemente imprime los mensajes de actualización.
 * Principio S (Single Responsibility): Su única responsabilidad es registrar los mensajes.
 */
public class BusStatusLogger implements BusObserver {
    @Override
    public void update(String message) {
        System.out.println("[LOG DE ESTADO DE BUS] " + message);
    }
}
