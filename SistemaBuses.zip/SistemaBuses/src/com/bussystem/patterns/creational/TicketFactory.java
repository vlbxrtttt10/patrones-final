package com.bussystem.patterns.creational;

import com.bussystem.model.ITicket;
import com.bussystem.model.StandardTicket;
import com.bussystem.model.VIPTicket;

/**
 * TicketFactory (Patrón Factory Method):
 * Proporciona un método para crear objetos ITicket sin especificar la clase concreta del boleto.
 * Principio O (Open/Closed): Si se añade un nuevo tipo de boleto (ej. PremiumTicket),
 * solo se modifica esta fábrica, no el código cliente que la usa.
 */
public class TicketFactory {
    public static ITicket createTicket(String type, int routeId, int busId, int passengerId, String seatNumber, double basePrice, String bookingDate) {
        switch (type.toLowerCase()) {
            case "standard":
                return new StandardTicket(routeId, busId, passengerId, seatNumber, basePrice, bookingDate);
            case "vip":
                return new VIPTicket(routeId, busId, passengerId, seatNumber, basePrice, bookingDate);
            default:
                throw new IllegalArgumentException("Tipo de boleto desconocido: " + type);
        }
    }
}
